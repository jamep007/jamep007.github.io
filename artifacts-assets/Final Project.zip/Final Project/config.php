<?php
    define('DB_HOST', 'localhost');
    define('DB_USER', 'reynoldsj');
    define('DB_PASSWORD', 'BombasticBaboon3527');
    define('DB_DATABASE', 'final-JR');
?>
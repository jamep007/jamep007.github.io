/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgfinal.project;

/**
 *
 * @author james
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Venusaur extends Pokemon {
    // Defines the names of the moves the Venusaur knows.
    private final String move1 = "Giga Drain";
    private final String move2 = "Sludge Bomb";
    private final String move3 = "Hidden Power";
    private final String move4 = "Synthesis";
    
    // Default constructor creates a basic Venusaur
    public Venusaur ( ) {
        super(363, 152, 224, 275, 259, 200);
        setType1("Grass");
        setType2("Poison");
    }
    
    // Accessors only for the names of the moves. Defines abstract method of parent class.
    @Override
    public String getMove1 ( ) {
        return move1;
    }
    
    @Override
    public String getMove2 ( ) {
        return move2;
    }
    
    @Override
    public String getMove3 ( ) {
        return move3;
    }
    
    @Override
    public String getMove4 ( ) {
        return move4;
    }
    
    // Move 1 simulates Giga Drain and does damage calculations using enemy and weather. Heals calling Venusaur. Defines abstract method of parent class.
    @Override
    public int move1 (Pokemon enemy, double weather, JLabel aLabel) {
        double STAB = 1.5, crit, type, type1 = 1, type2 = 1;
        if (.0625 > Math.random( )) {
            crit = 2;
        } else {
            crit = 1;
        }
        double random = (Math.random( ) * (1 - 0.855)) + .855;
        
        if ("Water".equals(enemy.getType1( )) || "Groud".equals(enemy.getType1( )) || "Rock".equals(enemy.getType1( ))) {
            type1 = 2;
        } else if ("Water".equals(enemy.getType2( )) || "Groud".equals(enemy.getType2( )) || "Rock".equals(enemy.getType2( ))) {
            type2 = 2;
        }
        
        if ("Grass".equals(enemy.getType1( )) || "Fire".equals(enemy.getType1( )) || "Poison".equals(enemy.getType1( )) || "Flying".equals(enemy.getType1( )) || "Bug".equals(enemy.getType1( )) || "Dragon".equals(enemy.getType1( ))) {
            type1 = .5;
        } else if ("Grass".equals(enemy.getType2( )) || "Fire".equals(enemy.getType2( )) || "Poison".equals(enemy.getType2( )) || "Flying".equals(enemy.getType2( )) || "Bug".equals(enemy.getType2( )) || "Dragon".equals(enemy.getType2( ))) {
            type2 = .5;
        }
        
        type = type1 * type2;
        int damage = (int) Math.round((((((((((((2 * 100) / 5) + 2) * 75) * ((double) getSpAtk( ) / enemy.getSpDef( ))) / 50) + 2) * weather) * crit) * random) * STAB) * type);
        aLabel.setText(aLabel.getText() + "Venusaur used Giga Drain!<br>");
        if (type == 0.0) {
            aLabel.setText(aLabel.getText() + "It was not effective!<br>");
        } else if(type < 1) {
            aLabel.setText(aLabel.getText() + "It wasn't very effective...<br>");
        } else if (type > 1) {
            aLabel.setText(aLabel.getText() + "It was super effective!<br>");
        }
        aLabel.setText(aLabel.getText() + "Venusaur dealt " + damage + " damage!<br>");
        heal((damage / 2), aLabel);
        return damage;
    }
    
    // Move 2 simulates Sludge Bomb and does damage calculations using enemy and weather. Has chance to poison enemy. Defines abstract method of parent class.
    @Override
    public int move2 (Pokemon enemy, double weather, JLabel aLabel) {
        double STAB = 1.5, crit, type, type1 = 1, type2 = 1;
        if (.0625 > Math.random( )) {
            crit = 2;
        } else {
            crit = 1;
        }
        double random = (Math.random( ) * (1 - 0.855)) + .855;
        
        if ("Grass".equals(enemy.getType1( )) || "Fairy".equals(enemy.getType1( ))) {
            type1 = 2;
        } else if ("Grass".equals(enemy.getType2( )) || "Fairy".equals(enemy.getType2( ))) {
            type2 = 2;
        }
        
        if ("Poison".equals(enemy.getType1( )) || "Ground".equals(enemy.getType1( )) || "Rock".equals(enemy.getType1( )) || "Ghost".equals(enemy.getType1( ))) {
            type1 = .5;
        } else if ("Poison".equals(enemy.getType2( )) || "Ground".equals(enemy.getType2( )) || "Rock".equals(enemy.getType2( )) || "Ghost".equals(enemy.getType2( ))) {
            type2 = .5;
        }
        
        if ("Steel".equals(enemy.getType1( ))) {
            type1 = 0;
        } else if ("Steel".equals(enemy.getType2( ))) {
            type2 = 0;
        }
        
        type = type1 * type2;
        
        int damage = (int) Math.round((((((((((((2 * 100) / 5) + 2) * 90) * ((double) getSpAtk( ) / enemy.getSpDef( ))) / 50) + 2) * weather) * crit) * random) * STAB) * type);
        aLabel.setText(aLabel.getText() + "Venusaur used Sludge Bomb!<br>");
        if (type == 0.0) {
            aLabel.setText(aLabel.getText() + "It was not effective!<br>");
        } else if(type < 1) {
            aLabel.setText(aLabel.getText() + "It wasn't very effective...<br>");;
        } else if (type > 1) {
            aLabel.setText(aLabel.getText() + "It was super effective!<br>");
        }
        aLabel.setText(aLabel.getText() + "Venusaur dealt " + damage + " damage!<br>");
        if(Math.random( ) <= 0.3) {
            enemy.setStatus('T');
            aLabel.setText(aLabel.getText() + "The opponent has been poisoned!<br>");
        }
        return damage;
    }
    
    // Move 3 simulates Hidden Power(Fire) and does damage calculations using enemy and weather. Defines abstract method of parent class.
    @Override
    public int move3 (Pokemon enemy, double weather, JLabel aLabel) {
        double STAB = 1, crit, type, type1 = 1, type2 = 1;
        if (.0625 > Math.random( )) {
            crit = 2;
        } else {
            crit = 1;
        }
        double random = (Math.random( ) * (1 - 0.855)) + .855;
        
        if ("Grass".equals(enemy.getType1( )) || "Ice".equals(enemy.getType1( )) || "Bug".equals(enemy.getType1( )) || "Steel".equals(enemy.getType1( ))) {
            type1 = 2;
        } else if ("Grass".equals(enemy.getType2( )) || "Ice".equals(enemy.getType2( )) || "Bug".equals(enemy.getType2( )) || "Steel".equals(enemy.getType2( ))) {
            type2 = 2;
        }
        
        if ("Fire".equals(enemy.getType1( )) || "Water".equals(enemy.getType1( )) || "Rock".equals(enemy.getType1( )) || "Dragon".equals(enemy.getType1( ))) {
            type1 = .5;
        } else if ("Fire".equals(enemy.getType2( )) || "Water".equals(enemy.getType2( )) || "Rock".equals(enemy.getType2( )) || "Dragon".equals(enemy.getType2( ))) {
            type2 = .5;
        }
        
        type = type1 * type2;
        
        int damage = (int) Math.round((((((((((((2 * 100) / 5) + 2) * 60) * ((double) getSpAtk( ) / enemy.getSpDef( ))) / 50) + 2) * weather) * crit) * random) * STAB) * type);
        aLabel.setText(aLabel.getText() + "Venusaur used Hidden Power!<br>");
        if (type == 0.0) {
            aLabel.setText(aLabel.getText() + "It was not effective!<br>");
        } else if(type < 1) {
            aLabel.setText(aLabel.getText() + "It wasn't very effective...<br>");;
        } else if (type > 1) {
            aLabel.setText(aLabel.getText() + "It was super effective!<br>");
        }
        aLabel.setText(aLabel.getText() + "Venusaur dealt " + damage + " damage!<br>");
        return damage;
    }
    
    // Move 4 simulates Synthesis. Heals half of calling Venusaurs maxHp. Does not use enemy and weather. Defines abstract method of parent class.
    @Override
    public int move4 (Pokemon enemy, double weather, JLabel aLabel) {
        int damage = 0;
        aLabel.setText(aLabel.getText() + "Venusaur used synthesis!<br>");
        heal((Math.round(getMaxHP( ) / 2)), aLabel);
        return damage;
    }
}

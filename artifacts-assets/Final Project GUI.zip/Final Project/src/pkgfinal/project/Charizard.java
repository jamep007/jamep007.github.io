/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgfinal.project;

/**
 *
 * @author james
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Charizard extends Pokemon {
    // Defines the names of the moves the Charizard knows.
    private final String move1 = "Dragon Claw";
    private final String move2 = "Earthquake";
    private final String move3 = "Flare Blitz";
    private final String move4 = "Swords Dance";
    
    // Default constructor creates a basic Charizard
    public Charizard ( ) {
        super(297, 293, 192, 228, 207, 299);
        setType1("Fire");
        setType2("Flying");
    }
    
    // Accessors only for the names of the moves. Defines abstract methods of parent class.
    @Override
    public String getMove1 ( ) {
        return move1;
    }
    
    @Override
    public String getMove2 ( ) {
        return move2;
    }
    
    @Override
    public String getMove3 ( ) {
        return move3;
    }
    
    @Override
    public String getMove4 ( ) {
        return move4;
    }
    
    // Move 1 simulates Dragon Claw and does damage calculations using enemy and weather. Defines abstract method of parent class.
    @Override
    public int move1 (Pokemon enemy, double weather, JLabel aLabel) {
        double STAB = 1, crit, type, type1 = 1, type2 = 1;
        double critNum = Math.random( );
        if (.0625 > critNum) {
            crit = 2;
        } else {
            crit = 1;
        }
        double random = (Math.random( ) * (1 - 0.855)) + .855;
        
        if ("Dragon".equals(enemy.getType1( ))) {
            type1 = 2;
        } else if ("Dragon".equals(enemy.getType2( ))) {
            type2 = 2;
        }
        
        if ("Steel".equals(enemy.getType1( ))) {
            type1 = .5;
        } else if ("Steel".equals(enemy.getType2( ))) {
            type2 = .5;
        }
        
        if ("Fairy".equals(enemy.getType1( ))) {
            type1 = 0;
        } else if ("Fairy".equals(enemy.getType2( ))) {
            type2 = 0;
        }
        
        type = type1 * type2;
        int damage = (int) Math.round(  ((((((((((200 / 5) + 2) * 80) * ((double) getAtk( ) / enemy.getDef( ))) / 50) + 2) * weather) * crit) * random) * STAB) * type   );
        aLabel.setText(aLabel.getText() + "Charizard used Dragon Claw!<br>");
        if (type == 0.0) {
            aLabel.setText(aLabel.getText() + "It was not effective!<br>");
        } else if(type < 1) {
            aLabel.setText(aLabel.getText() + "It wasn't very effective...<br>");
        } else if (type > 1) {
            aLabel.setText(aLabel.getText() + "It was super effective!<br>");
        }
        aLabel.setText(aLabel.getText() + "Charizard dealt " + damage + " damage!<br>");
        return damage;
    }
    
    // Move 2 simulates Earthquake and does damage calculations using enemy and weather. Defines abstract method of parent class.
    @Override
    public int move2 (Pokemon enemy, double weather, JLabel aLabel) {
        double STAB = 1, crit, type, type1 = 1, type2 = 1;
        if (.0625 > Math.random( )) {
            crit = 2;
        } else {
            crit = 1;
        }
        double random = (Math.random( ) * (1 - 0.855)) + .855;
        
        if ("Fire".equals(enemy.getType1( )) || "Electric".equals(enemy.getType1( )) || "Poison".equals(enemy.getType1( )) || "Rock".equals(enemy.getType1( )) || "Steel".equals(enemy.getType1( ))) {
            type1 = 2;
        } else if ("Fire".equals(enemy.getType2( )) || "Electric".equals(enemy.getType2( )) || "Poison".equals(enemy.getType2( )) || "Rock".equals(enemy.getType2( )) || "Steel".equals(enemy.getType2( ))) {
            type2 = 2;
        }
        
        if ("Grass".equals(enemy.getType1( )) || "Bug".equals(enemy.getType1( ))) {
            type1 = .5;
        } else if ("Grass".equals(enemy.getType2( )) || "Bug".equals(enemy.getType2( ))) {
            type2 = .5;
        }
        
        if ("Flying".equals(enemy.getType1( ))) {
            type1 = 0;
        } else if ("Flying".equals(enemy.getType2( ))) {
            type2 = 0;
        }
        
        type = type1 * type2;
        
        int damage = (int) Math.round((((((((((((2 * 100) / 5) + 2) * 100) * ((double) getAtk( ) / enemy.getDef( ))) / 50) + 2) * weather) * crit) * random) * STAB) * type);
        aLabel.setText(aLabel.getText() + "Charizard used Earthquake!<br>");
        if (type == 0.0) {
            aLabel.setText(aLabel.getText() + "It was not effective!<br>");
        } else if(type < 1) {
            aLabel.setText(aLabel.getText() + "It wasn't very effective...<br>");
        } else if (type > 1) {
            aLabel.setText(aLabel.getText() + "It was super effective!<br>");
        }
        aLabel.setText(aLabel.getText() + "Charizard dealt " + damage + " damage!<br>");
        return damage;
    }
    
    // Move 3 simulates Flare Blitz and does damage calculations using enemy and weather. Has recoil and has chance to burn enemy. Defines abstract method of parent class.
    @Override
    public int move3 (Pokemon enemy, double weather, JLabel aLabel) {
        double STAB = 1.5, crit, type, type1 = 1, type2 = 1;
        int recoil;
        if (.0625 > Math.random( )) {
            crit = 2;
        } else {
            crit = 1;
        }
        double random = (Math.random( ) * (1 - 0.855)) + .855;
        
        if ("Grass".equals(enemy.getType1( )) || "Ice".equals(enemy.getType1( )) || "Bug".equals(enemy.getType1( )) || "Steel".equals(enemy.getType1( ))) {
            type1 = 2;
        } else if ("Grass".equals(enemy.getType2( )) || "Ice".equals(enemy.getType2( )) || "Bug".equals(enemy.getType2( )) || "Steel".equals(enemy.getType2( ))) {
            type2 = 2;
        }
        
        if ("Fire".equals(enemy.getType1( )) || "Water".equals(enemy.getType1( )) || "Rock".equals(enemy.getType1( )) || "Dragon".equals(enemy.getType1( ))) {
            type1 = .5;
        } else if ("Fire".equals(enemy.getType2( )) || "Water".equals(enemy.getType2( )) || "Rock".equals(enemy.getType2( )) || "Dragon".equals(enemy.getType2( ))) {
            type2 = .5;
        }
        
        type = type1 * type2;
        
        if(getStatus( ) == 'F') {
            setStatus('H');
            aLabel.setText(aLabel.getText() + "Charizard thawed out!<br>");
        }
        
        int damage = (int) Math.round((((((((((((2 * 100) / 5) + 2) * 120) * ((double) getAtk( ) / enemy.getDef( ))) / 50) + 2) * weather) * crit) * random) * STAB) * type);
        aLabel.setText(aLabel.getText() + "Charizard used Flare Blitz!<br>");
        if (type == 0.0) {
            aLabel.setText(aLabel.getText() + "It was not effective!<br>");
        } else if(type < 1) {
            aLabel.setText(aLabel.getText() + "It wasn't very effective...<br>");
        } else if (type > 1) {
            aLabel.setText(aLabel.getText() + "It was super effective!<br>");
        }
        aLabel.setText(aLabel.getText() + "Charizard dealt " + damage + " damage!<br>");
        
        if(.1 > Math.random( )) {
            enemy.setStatus('B');
            enemy.refreshStats( );
            aLabel.setText(aLabel.getText() + "The opponent has been burned!<br>");
        }
        if(damage >= enemy.getCurrentHP( )) {
            recoil = (enemy.getCurrentHP() / 3);
            damage(recoil, aLabel);
        } else {
            recoil = (damage / 3);
            damage(recoil, aLabel);
        }
        aLabel.setText(aLabel.getText() + "Charizard dealt " + recoil + " damage to itself in recoil.<br>");
        return damage;
    }
    
    // Move 4 simulates Swords dance. Increases calling Charizards attack using stat stages and modifiers. Does not use enemy and weather. Defines abstract method of parent class.
    @Override
    public int move4 (Pokemon enemy, double weather, JLabel aLabel) {
        int damage = 0;
        aLabel.setText(aLabel.getText() + "Charizard used Swords Dance!<br>");
        setAtkStage(2);
        aLabel.setText(aLabel.getText() + "Charizard's attack sharply increased!<br>");
        return damage;
    }
}

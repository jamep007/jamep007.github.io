/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgfinal.project;

/**
 *
 * @author james
 */
import java.util.Scanner;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class FinalProject {
    
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner input = new Scanner(System.in);
        Pokemon player1Pokemon = null; // Declaring a player 1 pokemon. No child class picked yet
        Pokemon player2Pokemon = null; // Declaring a player 2 pokemon. No child class picked yet
        char pokemonPick, response; // pokemonPick to pick a Pokemon & can help pick player 2's move. Response picks player 1's move and also if user wants to quit the program.
        
        FinalProject gui = new FinalProject( );
        gui.setVisible(true);
        
        System.out.println("This project is designed to simulate a Pokemon battle between two players.");
        
        // Simulation begins. Repeats the simulation until the user decides to quit
        do {
            
            // Both players pick their Pokemon
            // Displays options.
            System.out.println("\nPlayer 1: Choose your Pokemon."
            + "\nPress 'C' for Charizard"
            + "\nPress 'B' for Blastoise"
            + "\nPress 'V' for Venusaur");
            pokemonPick = input.next( ).charAt(0);
            
            // Chooses a class for the player's Pokemon depending on what their response is.
            switch (pokemonPick) {
                case 'C':
                    player1Pokemon = new Charizard( );
                    break;
                case 'c':
                    player1Pokemon = new Charizard( );
                    break;
                case 'B':
                    player1Pokemon = new Blastoise( );
                    break;
                case 'b':
                    player1Pokemon = new Blastoise( );
                    break;
                case 'V':
                    player1Pokemon = new Venusaur( );
                    break;
                case 'v':
                    player1Pokemon = new Venusaur( );
                    break;
                default:
                    System.out.println("Error: Did not pick a Pokemon.");
                    System.exit(0);
            }
        
            // Displays options.
            System.out.println("\nPlayer 2: Choose your Pokemon."
            + "\nPress 'C' for Charizard"
            + "\nPress 'B' for Blastoise"
            + "\nPress 'V' for Venusaur");
            pokemonPick = input.next( ).charAt(0);
            
            // Chooses a class for the player's Pokemon depending on what their response is.
            switch (pokemonPick) {
                case 'C':
                    player2Pokemon = new Charizard( );
                    break;
                case 'c':
                    player2Pokemon = new Charizard( );
                    break;
                case 'B':
                    player2Pokemon = new Blastoise( );
                    break;
                case 'b':
                    player2Pokemon = new Blastoise( );
                    break;
                case 'V':
                    player2Pokemon = new Venusaur( );
                    break;
                case 'v':
                    player2Pokemon = new Venusaur( );
                    break;
                default:
                    System.out.println("Error: Did not pick a Pokemon.");
                    System.exit(0);
            }
            
            // Turns begin! Turns end when a Pokemon has fainted.
            do {
                // Player 1 picks move
                System.out.print("\nPlayer 1: ");
                player1Pokemon.displayStatus( );
                System.out.println("Player 1, pick your move.\n"
                + "Press '1' for " + player1Pokemon.getMove1( ) + "\n"
                + "Press '2' for " + player1Pokemon.getMove2( ) + "\n"
                + "Press '3' for " + player1Pokemon.getMove3( ) + "\n"
                + "Press '4' for " + player1Pokemon.getMove4( ));
                response = input.next( ).charAt(0);
                if ((response != '1') && (response != '2') && (response != '3') && (response != '4')) {
                    System.out.println("Error: Did not choose a move.");
                    System.exit(0);
                }
                
                // Player 2 picks move
                System.out.print("\nPlayer 2: ");
                player2Pokemon.displayStatus( );
                System.out.println("Player 2, pick your move.\n"
                + "Press '1' for " + player2Pokemon.getMove1( ) + "\n"
                + "Press '2' for " + player2Pokemon.getMove2( ) + "\n"
                + "Press '3' for " + player2Pokemon.getMove3( ) + "\n"
                + "Press '4' for " + player2Pokemon.getMove4( ));
                pokemonPick = input.next( ).charAt(0);
                if ((pokemonPick != '1') && (pokemonPick != '2') && (pokemonPick != '3') && (pokemonPick != '4')) {
                    System.out.println("Error: Did not choose a move.");
                    System.exit(0);
                }
                
                // Pokemon make their move. Whoever is fastest goes first. Default is player 1's Pokemon goes first.
                if (player1Pokemon.getSpd( ) > player2Pokemon.getSpd( )) {
                    System.out.println("");
                    // Checks to see if the Pokemon can move based on status conditions.
                    // If the Pokemon can move, it chooses the move the player picked.
                    switch (response) {
                        case '1':
                            if (player1Pokemon.canMove( ))
                                player2Pokemon.damage(player1Pokemon.move1(player2Pokemon, 1));
                            break;
                        case '2':
                            if (player1Pokemon.canMove( ))
                                player2Pokemon.damage(player1Pokemon.move2(player2Pokemon, 1));
                            break;
                        case '3':
                            if (player1Pokemon.canMove( ))
                                player2Pokemon.damage(player1Pokemon.move3(player2Pokemon, 1));
                            break;
                        case '4':
                            if (player1Pokemon.canMove( ))
                                player2Pokemon.damage(player1Pokemon.move4(player2Pokemon, 1));
                            break;
                        default:
                            System.out.println("Error: Did not choose a move.");
                            System.exit(0);
                            break;
                    }
                    
                    // Checks to see if defending Pokemon fainted.
                    if (player2Pokemon.getCurrentHP( ) == 0) {
                        System.out.println("Player 2's Pokemon has fainted!");
                        continue;
                    }
                    
                    // Checks to see if the Pokemon can move based on status conditions.
                    // If the Pokemon can move, it chooses the move the player picked.
                    switch (pokemonPick) {
                        case '1':
                            if (player2Pokemon.canMove( ))
                                player1Pokemon.damage(player2Pokemon.move1(player1Pokemon, 1));
                            break;
                        case '2':
                            if (player2Pokemon.canMove( ))
                                player1Pokemon.damage(player2Pokemon.move2(player1Pokemon, 1));
                            break;
                        case '3':
                            if (player2Pokemon.canMove( ))
                                player1Pokemon.damage(player2Pokemon.move3(player1Pokemon, 1));
                            break;
                        case '4':
                            if (player2Pokemon.canMove( ))
                                player1Pokemon.damage(player2Pokemon.move4(player1Pokemon, 1));
                            break;
                        default:
                            System.out.println("Error: Did not choose a move.");
                            System.exit(0);
                            break;
                    }
                    
                    // Checks to see if defending Pokemon fainted.
                    if (player1Pokemon.getCurrentHP( ) == 0) {
                        System.out.println("Player 1's Pokemon has fainted!");
                        continue;
                    }
                    
                    // Checks to see if the Pokemon take damage based on their status condition.
                    player1Pokemon.checkChipDMG( );
                    player2Pokemon.checkChipDMG( );
                    
                } else if (player2Pokemon.getSpd( ) > player1Pokemon.getSpd( )) {
                    System.out.println("");
                    // Checks to see if the Pokemon can move based on status conditions.
                    // If the Pokemon can move, it chooses the move the player picked.
                    switch (pokemonPick) {
                        case '1':
                            if (player2Pokemon.canMove( ))
                                player1Pokemon.damage(player2Pokemon.move1(player1Pokemon, 1));
                            break;
                        case '2':
                            if (player2Pokemon.canMove( ))
                                player1Pokemon.damage(player2Pokemon.move2(player1Pokemon, 1));
                            break;
                        case '3':
                            if (player2Pokemon.canMove( ))
                                player1Pokemon.damage(player2Pokemon.move3(player1Pokemon, 1));
                            break;
                        case '4':
                            if (player2Pokemon.canMove( ))
                                player1Pokemon.damage(player2Pokemon.move4(player1Pokemon, 1));
                            break;
                        default:
                            System.out.println("Error: Did not choose a move.");
                            System.exit(0);
                            break;
                    }
                    
                    // Checks to see if defending Pokemon fainted.
                    if (player1Pokemon.getCurrentHP( ) == 0) {
                        System.out.println("Player 1's Pokemon has fainted!");
                        continue;
                    }
                    
                    // Checks to see if the Pokemon can move based on status conditions.
                    // If the Pokemon can move, it chooses the move the player picked.
                    switch (response) {
                        case '1':
                            if (player1Pokemon.canMove( ))
                                player2Pokemon.damage(player1Pokemon.move1(player2Pokemon, 1));
                            break;
                        case '2':
                            if (player1Pokemon.canMove( ))
                                player2Pokemon.damage(player1Pokemon.move2(player2Pokemon, 1));
                            break;
                        case '3':
                            if (player1Pokemon.canMove( ))
                                player2Pokemon.damage(player1Pokemon.move3(player2Pokemon, 1));
                            break;
                        case '4':
                            if (player1Pokemon.canMove( ))
                                player2Pokemon.damage(player1Pokemon.move4(player2Pokemon, 1));
                            break;
                        default:
                            System.out.println("Error: Did not choose a move.");
                            System.exit(0);
                            break;
                    }
                    
                    // Checks to see if defending Pokemon fainted.
                    if (player2Pokemon.getCurrentHP( ) == 0) {
                        System.out.println("Player 2's Pokemon has fainted!");
                        continue;
                    }
                    
                    // Checks to see if the Pokemon take damage based on their status condition.
                    player1Pokemon.checkChipDMG( );
                    player2Pokemon.checkChipDMG( );
                    
                } else {
                    System.out.println("");
                    // Checks to see if the Pokemon can move based on status conditions.
                    // If the Pokemon can move, it chooses the move the player picked.
                    switch (response) {
                        case '1':
                            if (player1Pokemon.canMove( ))
                                player2Pokemon.damage(player1Pokemon.move1(player2Pokemon, 1));
                            break;
                        case '2':
                            if (player1Pokemon.canMove( ))
                                player2Pokemon.damage(player1Pokemon.move2(player2Pokemon, 1));
                            break;
                        case '3':
                            if (player1Pokemon.canMove( ))
                                player2Pokemon.damage(player1Pokemon.move3(player2Pokemon, 1));
                            break;
                        case '4':
                            if (player1Pokemon.canMove( ))
                                player2Pokemon.damage(player1Pokemon.move4(player2Pokemon, 1));
                            break;
                        default:
                            System.out.println("Error: Did not choose a move.");
                            System.exit(0);
                            break;
                    }
                    
                    // Checks to see if defending Pokemon fainted.
                    if (player2Pokemon.getCurrentHP( ) == 0) {
                        System.out.println("Player 2's Pokemon has fainted!");
                        continue;
                    }
                    
                    // Checks to see if the Pokemon can move based on status conditions.
                    // If the Pokemon can move, it chooses the move the player picked.
                    switch (pokemonPick) {
                        case '1':
                            if (player2Pokemon.canMove( ))
                                player1Pokemon.damage(player2Pokemon.move1(player1Pokemon, 1));
                            break;
                        case '2':
                            if (player2Pokemon.canMove( ))
                                player1Pokemon.damage(player2Pokemon.move2(player1Pokemon, 1));
                            break;
                        case '3':
                            if (player2Pokemon.canMove( ))
                                player1Pokemon.damage(player2Pokemon.move3(player1Pokemon, 1));
                            break;
                        case '4':
                            if (player2Pokemon.canMove( ))
                                player1Pokemon.damage(player2Pokemon.move4(player1Pokemon, 1));
                            break;
                        default:
                            System.out.println("Error: Did not choose a move.");
                            System.exit(0);
                            break;
                    }
                    
                    // Checks to see if defending Pokemon fainted.
                    if (player1Pokemon.getCurrentHP( ) == 0) {
                        System.out.println("Player 1's Pokemon has fainted!");
                        continue;
                    }
                    
                    // Checks to see if the Pokemon take damage based on their status condition.
                    player1Pokemon.checkChipDMG( );
                    player2Pokemon.checkChipDMG( );
                    
                }    
            } while (player1Pokemon.getCurrentHP( ) != 0 && player2Pokemon.getCurrentHP( ) != 0);
            System.out.println("Quit? Press 'q' to quit.");
            response = input.next( ).charAt(0);
        } while (response != 'q' && response != 'Q');
        
    }
    
}
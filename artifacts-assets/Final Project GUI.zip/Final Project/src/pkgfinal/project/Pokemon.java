/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgfinal.project;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 *
 * @author james
 */
public abstract class Pokemon {
    private int baseAtk, baseSpAtk, baseDef, baseSpDef, baseSpd; // Defined base stats
    private int maxHp, currentHp, atk, spAtk, def, spDef, spd; // Defines actual stats derived from base stats and modifiers
    private char status; //H for healthy, D for fainted, B for burn, S for sleep, F for frozen, C for confused, L for flinch, P for paralysis, T for poison, X for badly poisoned.
    private int atkStage, spAtkStage, defStage, spDefStage, spdStage; // Defines stat stages for modifier calculation
    private double atkMod, spAtkMod, defMod, spDefMod, spdMod; // Declares the actual stat modifiers
    private int sleepCounter; // Counter to see if Pokemon can become healthy if it has certain status conditions
    private int toxicCounter; // COunter to see how much a Pokemon takes damage from being badly poisoned.
    String type1, type2; // Declares the types the Pokemon can have.
    
    public Pokemon ( ) { // Default constructor should never be used except by super( ). Initializes basic stats.
        atkStage = 1;
        spAtkStage = 1;
        defStage = 1;
        spDefStage = 1;
        spdStage = 1;
        atkMod = 1.0;
        spAtkMod = 1.0;
        defMod = 1.0;
        spDefMod = 1.0;
        spdMod = 1.0;
        maxHp = 100;
        currentHp = 100;
        baseAtk = 100;
        baseSpAtk = 100;
        baseDef = 100;
        baseSpDef = 100;
        baseSpd = 100;
        atk = (int) Math.round(baseAtk * atkMod);
        spAtk = (int) Math.round(baseSpAtk * spAtkMod);
        def = (int) Math.round(baseDef * defMod);
        spDef = (int) Math.round(baseSpDef * spDefMod);
        spd = (int) Math.round(baseSpd * spdMod);
        status = 'H';
        sleepCounter = 0;
        toxicCounter = 0;
    }
    
    // Creates a new Pokemon based on the stats given as input. Should never be used except by super(health, attack, spAttack, defense, spDefense, speed);
    public Pokemon (int health, int attack, int spAttack, int defense, int spDefense, int speed) {
        atkStage = 1;
        spAtkStage = 1;
        defStage = 1;
        spDefStage = 1;
        spdStage = 1;
        atkMod = 1.0;
        spAtkMod = 1.0;
        defMod = 1.0;
        spDefMod = 1.0;
        spdMod = 1.0;
        maxHp = health;
        currentHp = health;
        baseAtk = attack;
        baseSpAtk = spAttack;
        baseDef = defense;
        baseSpDef = spDefense;
        baseSpd = speed;
        atk = (int) Math.round(baseAtk * atkMod);
        spAtk = (int) Math.round(baseSpAtk * spAtkMod);
        def = (int) Math.round(baseDef * defMod);
        spDef = (int) Math.round(baseSpDef * spDefMod);
        spd = (int) Math.round(baseSpd * spdMod);
        status = 'H';
        sleepCounter = 0;
        toxicCounter = 0;
    }
    
    
    //Accessors & mutator methods for the variables
    public String getType1 ( ) {
        return type1;
    }
    
    public void setType1 (String type) {
        type1 = type;
    }
    
    public String getType2 ( ) {
        return type2;
    }
    
    public void setType2 (String type) {
        type2 = type;
    }
    
    public int getMaxHP ( ) {
        return maxHp;
    }
    
    public void setMaxHP (int number) {
        maxHp = number;
    }
    
    public int getCurrentHP ( ) {
        return currentHp;
    }
    
    public void setCurrentHP (int number) {
        currentHp = number;
    }
    
    public int getAtk ( ) {
        return atk;
    }
    
    // Sets attack but will be halved if burned
    public void setAtk (int number) {
        if(status == 'H') {
            atk = (int) Math.round(number * atkMod);
        } else if(status == 'B') {
            atk = (int) Math.round((number * atkMod) / 2);
        }
    }
    
    public int getSpAtk ( ) {
        return spAtk;
    }
    
    public void setSpAtk (int number) {
        spAtk = number;
    }
    
    public int getDef ( ) {
        return def;
    }
    
    public void setDef (int number) {
        def = number;
    }
    
    public int getSpDef ( ) {
        return spDef;
    }
    
    public void setSpDef (int number) {
        spDef = number;
    }
    
    public int getSpd ( ) {
        return spd;
    }
    
    // Sets speed but will be halved if paralyzed
    public void setSpd (int number) {
        if(status == 'H') {
            spd = (int) Math.round(number * spdMod);
        } else if(status == 'P') {
            spd = (int) Math.round((number * spdMod) / 2);
        }
    }
    
    
    // Accessors and mutators for the stat stages
    // Mutator methods change the actual modifiers based on what stage the stat is at. Then applies said modifiers
    public int getAtkStage ( ) {
        return atkStage;
    }
    
    public void setAtkStage (int number) {
        atkStage += number;
        switch (atkStage) {
            case -6:
                atkMod = 2/8;
                break;
            case -5:
                atkMod = 2/7;
                break;
            case -4:
                atkMod = 2/6;
                break;
            case -3:
                atkMod = 2/5;
                break;
            case -2:
                atkMod = 2/4;
                break;
            case -1:
                atkMod = 2/3;
                break;
            case 0:
                atkMod = 2/2;
                break;
            case 1:
                atkMod = 3/2;
                break;
            case 2:
                atkMod = 4/2;
                break;
            case 3:
                atkMod = 5/2;
                break;
            case 4:
                atkMod = 6/2;
                break;
            case 5:
                atkMod = 7/2;
                break;
            case 6:
                atkMod = 8/2;
                break;
        }
        refreshStats( );
    }
    
    public int getSpAtkStage ( ) {
        return spAtkStage;
    }
    
    public void setSpAtkStage (int number) {
        spAtkStage += number;
        switch (spAtkStage) {
            case -6:
                spAtkMod = 2/8;
                break;
            case -5:
                spAtkMod = 2/7;
                break;
            case -4:
                spAtkMod = 2/6;
                break;
            case -3:
                spAtkMod = 2/5;
                break;
            case -2:
                spAtkMod = 2/4;
                break;
            case -1:
                spAtkMod = 2/3;
                break;
            case 0:
                spAtkMod = 2/2;
                break;
            case 1:
                spAtkMod = 3/2;
                break;
            case 2:
                spAtkMod = 4/2;
                break;
            case 3:
                spAtkMod = 5/2;
                break;
            case 4:
                spAtkMod = 6/2;
                break;
            case 5:
                spAtkMod = 7/2;
                break;
            case 6:
                spAtkMod = 8/2;
                break;
        }
        refreshStats( );
    }
    
    public int getDefStage ( ) {
        return defStage;
    }
    
    public void setDefStage (int number) {
        defStage += number;
        switch (defStage) {
            case -6:
                defMod = 2/8;
                break;
            case -5:
                defMod = 2/7;
                break;
            case -4:
                defMod = 2/6;
                break;
            case -3:
                defMod = 2/5;
                break;
            case -2:
                defMod = 2/4;
                break;
            case -1:
                defMod = 2/3;
                break;
            case 0:
                defMod = 2/2;
                break;
            case 1:
                defMod = 3/2;
                break;
            case 2:
                defMod = 4/2;
                break;
            case 3:
                defMod = 5/2;
                break;
            case 4:
                defMod = 6/2;
                break;
            case 5:
                defMod = 7/2;
                break;
            case 6:
                defMod = 8/2;
                break;
        }
        refreshStats( );
    }
    
    public int getSpDefStage ( ) {
        return spdStage;
    }
    
    public void setSpDefStage (int number) {
        spDefStage += number;
        switch (spDefStage) {
            case -6:
                spDefMod = 2/8;
                break;
            case -5:
                spDefMod = 2/7;
                break;
            case -4:
                spDefMod = 2/6;
                break;
            case -3:
                spDefMod = 2/5;
                break;
            case -2:
                spDefMod = 2/4;
                break;
            case -1:
                spDefMod = 2/3;
                break;
            case 0:
                spDefMod = 2/2;
                break;
            case 1:
                spDefMod = 3/2;
                break;
            case 2:
                spDefMod = 4/2;
                break;
            case 3:
                spDefMod = 5/2;
                break;
            case 4:
                spDefMod = 6/2;
                break;
            case 5:
                spDefMod = 7/2;
                break;
            case 6:
                spDefMod = 8/2;
                break;
        }
        refreshStats( );
    }
    
    public int getSpdStage ( ) {
        return spdStage;
    }
    
    public void setSpdStage (int number) {
        spdStage += number;
        switch (spdStage) {
            case -6:
                spdMod = 2/8;
                break;
            case -5:
                spdMod = 2/7;
                break;
            case -4:
                spdMod = 2/6;
                break;
            case -3:
                spdMod = 2/5;
                break;
            case -2:
                spdMod = 2/4;
                break;
            case -1:
                spdMod = 2/3;
                break;
            case 0:
                spdMod = 2/2;
                break;
            case 1:
                spdMod = 3/2;
                break;
            case 2:
                spdMod = 4/2;
                break;
            case 3:
                spdMod = 5/2;
                break;
            case 4:
                spdMod = 6/2;
                break;
            case 5:
                spdMod = 7/2;
                break;
            case 6:
                spdMod = 8/2;
                break;
        }
        refreshStats( );
    }
    
    // Returns status
    public char getStatus ( ) {
        return status;
    }
    
    // Sets status.
    public void setStatus (char condition) {
        if ((condition == 'H') || (condition == 'D') || (condition == 'B') || (condition == 'F') || (condition == 'S') || (condition == 'C') || (condition == 'L') || (condition == 'P') || (condition == 'T') || (condition == 'X')) {
            status = condition;
        } else {
            System.out.println("Status exception thrown.");
            System.exit(0);
        }
    }
    
    // Applies any modifiers if not already applied.
    public void refreshStats ( ) {
        switch (status) {
            case 'B':
                atk = (int) Math.round((baseAtk * atkMod) / 2);
                spAtk = (int) Math.round(baseSpAtk * spAtkMod);
                def = (int) Math.round(baseDef * defMod);
                spDef = (int) Math.round(baseSpDef * spDefMod);
                spd = (int) Math.round(baseSpd * spdMod);
                break;
            case 'P':
                atk = (int) Math.round(baseAtk * atkMod);
                spAtk = (int) Math.round(baseSpAtk * spAtkMod);
                def = (int) Math.round(baseDef * defMod);
                spDef = (int) Math.round(baseSpDef * spDefMod);
                spd = (int) Math.round((baseSpd * spdMod) / 2);
                break;
            default:
                atk = (int) Math.round(baseAtk * atkMod);
                spAtk = (int) Math.round(baseSpAtk * spAtkMod);
                def = (int) Math.round(baseDef * defMod);
                spDef = (int) Math.round(baseSpDef * spDefMod);
                spd = (int) Math.round(baseSpd * spdMod);
                break;
        }
    }
    
    // Damages the calling Pokemon based on the number given
    public void damage (int number, JLabel aLabel) {
        if (number >= 0) {
            if (number >= currentHp) {
            currentHp = 0;
            setStatus('D');
            } else {
                currentHp -= number;
            }
        } else {
            aLabel.setText(aLabel.getText() + "Damage is less than zero.<br>");
            System.exit(0);
        }
    }
    
    // Heals the calling Pokemon based on the number given.
    public void heal (int number, JLabel aLabel) {
        if((number + currentHp) > maxHp) {
            currentHp = maxHp;
            aLabel.setText(aLabel.getText() + "Healed to full HP!<br>");
        } else {
            currentHp += number;
            aLabel.setText(aLabel.getText() + "Healed " + number + " HP.<br>");
        }
    }
    
    // Checks to see if calling Pokemon can move based on status conditions.
    public boolean canMove (JLabel aLabel) {
        int damage;
        switch (this.getStatus( )) {
            case 'P':
                if (.25 > Math.random( )) {
                    return true;
                } else {
                    aLabel.setText(aLabel.getText() + "This Pokemon is paralyzed!<br>");
                    return false;
                }
            case 'S':
            {
                sleepCounter++;
                double rand = Math.random( );
                if ((sleepCounter >= 5) && (1 >= rand)) {
                    aLabel.setText(aLabel.getText() + "This Pokemon woke up!<br>");
                    this.setStatus('H');
                    sleepCounter = 0;
                    return true;
                } else if ((sleepCounter >= 4) && (.75 >= rand)) {
                    aLabel.setText(aLabel.getText() + "This Pokemon woke up!<br>");
                    this.setStatus('H');
                    sleepCounter = 0;
                    return true;
                } else if ((sleepCounter >= 3) && (.5 >= rand)) {
                    aLabel.setText(aLabel.getText() + "This Pokemon woke up!<br>");
                    this.setStatus('H');
                    sleepCounter = 0;
                    return true;
                } else if ((sleepCounter >= 2) && (.25 >= rand)) {
                    aLabel.setText(aLabel.getText() + "This Pokemon woke up!<br>");
                    this.setStatus('H');
                    sleepCounter = 0;
                    return true;
                } else {
                    aLabel.setText(aLabel.getText() + "This Pokemon is still sleeping. ZZZzzz...<br>");
                    return false;
                }
            }
            case 'C':
            {
                sleepCounter++;
                double rand = Math.random( );
                if ((sleepCounter >= 5) && (1 >= rand)) {
                    aLabel.setText(aLabel.getText() + "This Pokemon is no longer confused!<br>");
                    this.setStatus('H');
                    sleepCounter = 0;
                    return true;
                } else if ((sleepCounter >= 4) && (.75 >= rand)) {
                    aLabel.setText(aLabel.getText() + "This Pokemon is no longer confused!<br>");
                    this.setStatus('H');
                    sleepCounter = 0;
                    return true;
                } else if ((sleepCounter >= 3) && (.5 >= rand)) {
                    aLabel.setText(aLabel.getText() + "This Pokemon is no longer confused!<br>");
                    this.setStatus('H');
                    sleepCounter = 0;
                    return true;
                } else if ((sleepCounter >= 2) && (.25 >= rand)) {
                    aLabel.setText(aLabel.getText() + "This Pokemon is no longer confused!<br>");
                    this.setStatus('H');
                    sleepCounter = 0;
                    return true;
                } else {
                    aLabel.setText(aLabel.getText() + "This Pokemon hurt itself in confusion!<br>");
                    damage = (int) Math.round((this.getMaxHP( ) * .2));
                    this.damage(damage, aLabel);
                    return false;
                }
            }
            case 'L':
                aLabel.setText(aLabel.getText() + "This Pokemon flinched!<br>");
                this.setStatus('H');
                return false;
            case 'F':
            {
                sleepCounter++;
                double rand = Math.random( );
                if ((sleepCounter >= 5) && (1 >= rand)) {
                    aLabel.setText(aLabel.getText() + "This Pokemon thawed out!<br>");
                    this.setStatus('H');
                    sleepCounter = 0;
                    return true;
                } else if ((sleepCounter >= 4) && (.75 >= rand)) {
                    aLabel.setText(aLabel.getText() + "This Pokemon thawed out!<br>");
                    this.setStatus('H');
                    sleepCounter = 0;
                    return true;
                } else if ((sleepCounter >= 3) && (.5 >= rand)) {
                    aLabel.setText(aLabel.getText() + "This Pokemon thawed out!<br>");
                    this.setStatus('H');
                    sleepCounter = 0;
                    return true;
                } else if ((sleepCounter >= 2) && (.25 >= rand)) {
                    aLabel.setText(aLabel.getText() + "This Pokemon thawed out!<br>");
                    this.setStatus('H');
                    sleepCounter = 0;
                    return true;
                } else {
                    aLabel.setText(aLabel.getText() + "This Pokemon is frozen!<br>");
                    return false;
                }
            }
            default:
                return true;
        }
    }
    
    // Checks to see if calling Pokemon takes damage based on status conditions.
    public void checkChipDMG (JLabel aLabel) {
        int damage;
        switch (this.getStatus( )) {
            case 'B':
                damage = (int) Math.round((this.getMaxHP( ) * 0.0625));
                this.damage(damage, aLabel);
                aLabel.setText(aLabel.getText() + "This Pokemon took " + damage + " damage from its burn.<br>");
                break;
            case 'T':
                damage = (int) Math.round((this.getMaxHP( ) * 0.0625));
                this.damage(damage, aLabel);
                aLabel.setText(aLabel.getText() + "This Pokemon took " + damage + " damage from being poisoned.<br>");
                break;
            case 'X':
                toxicCounter++;
                damage = (int) Math.round((this.getMaxHP( ) * ((double) 0.0625 * toxicCounter)));
                this.damage(damage, aLabel);
                aLabel.setText(aLabel.getText() + "This Pokemon took " + damage + " damage from being badly poisoned.<br>");
                break;
            default:
                break;
        }
    }
    
    // Displays the current status of the calling Pokemon. Only includes status condition and current HP.
    public void displayStatus (JLabel aLabel) {
        aLabel.setText(aLabel.getText() + "Your Pokemon's current status is: " + currentHp + "/" + maxHp + " HP<br>");
        switch (status) {
            case 'H':
                aLabel.setText(aLabel.getText() + "This Pokemon has no status conditions.<br>");
                break;
            case 'D':
                aLabel.setText(aLabel.getText() + "This Pokemon has fainted!<br>");
                break;
            case 'B':
                aLabel.setText(aLabel.getText() + "This Pokemon has been burned.<br>");
                break;
            case 'F':
                aLabel.setText(aLabel.getText() + "This Pokemon is frozen.<br>");
                break;
            case 'C':
                aLabel.setText(aLabel.getText() + "This Pokemon is confused!<br>");
                break;
            case 'L':
                aLabel.setText(aLabel.getText() + "This pokemon flinched!<br>");
                break;
            case 'P':
                aLabel.setText(aLabel.getText() + "This Pokemon is paralyzed.<br>");
                break;
            case 'T':
                aLabel.setText(aLabel.getText() + "This Pokemon has been poisoned.<br>");
                break;
            case 'X':
                aLabel.setText(aLabel.getText() + "This Pokemon has been badly poisoned!<br>");
                break;
            
        }
        
    }
    
    // These declare moves that the Pokemon can know
    public abstract int move1(Pokemon enemy, double weather, JLabel aLabel);
    public abstract int move2(Pokemon enemy, double weather, JLabel aLabel);
    public abstract int move3(Pokemon enemy, double weather, JLabel aLabel);
    public abstract int move4(Pokemon enemy, double weather, JLabel aLabel);
    
    // These delcare the names for the moves the Pokemon can know
    public abstract String getMove1( );
    public abstract String getMove2( );
    public abstract String getMove3( );
    public abstract String getMove4( );
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgfinal.project;

/**
 *
 * @author james
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.imageio.ImageIO;

public class FinalProject extends JFrame implements ActionListener{
    public static final int WIDTH = 512;
    public static final int HEIGHT = 288;
    
    public int p1Pokemon = 0, p2Pokemon = 0;
    // 1: Charizard is selected
    // 2: Blastoise is selected
    // 3: Venusaur is selected
    
    private Pokemon player1Pokemon, player2Pokemon;
    
    public boolean player1_isSelected = true, player2_isSelected = false, battle = false;
    // To know which is selected at any particular time
    
    public String p1SelectedMove = "", p2SelectedMove = "";
    // For error checking mostly. A string that holds the selected move's name
    
    private JPanel textPanel;
    private JButton button1, button2, button3, button4, button5;
    
    JLabel commentText = new JLabel("Welcome to the Pokemon Battle Simulator! Player 1, Please choose your Pokemon:");
    
    public FinalProject ( ) 
    {
        super("Pokemon Battle Simulator");
        setSize(WIDTH, HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout( ));
        
        JPanel biggerPanel = new JPanel( );
        biggerPanel.setLayout(new GridLayout(1, 4));
        
        ImageIcon img = new ImageIcon("Images/background.png");
        ImageIcon imgc = new ImageIcon("Images/charizard.jpg");
        ImageIcon imgb = new ImageIcon("Images/blastoise.jpg");
        ImageIcon imgv = new ImageIcon("Images/venusaur.png");
        
        JLabel background = new JLabel("", img, JLabel.CENTER);
        JLabel charizard = new JLabel("", imgc, JLabel.CENTER);
        JLabel charizard2 = new JLabel("", imgc, JLabel.CENTER);
        JLabel blastoise = new JLabel("", imgb, JLabel.CENTER);
        JLabel blastoise2 = new JLabel("", imgb, JLabel.CENTER);
        JLabel venusaur = new JLabel("", imgv, JLabel.CENTER);
        JLabel venusaur2 = new JLabel("", imgv, JLabel.CENTER);
        background.setBounds(0, 0, WIDTH, HEIGHT);
        add(background);
        
        
        textPanel = new JPanel( );
        textPanel.setBackground(Color.WHITE);
        biggerPanel.add(textPanel);
        textPanel.add(commentText);
        textPanel.revalidate();
        
        add(biggerPanel, BorderLayout.CENTER);
        
        JPanel buttonPanel = new JPanel( );
        textPanel.add(commentText);
        buttonPanel.setBackground(Color.LIGHT_GRAY);
        buttonPanel.setLayout(new FlowLayout( ));
        
        // ------------------------------- BUTTON 1 -------------------------------
        button1 = new JButton("Charizard");
        button1.setBackground(Color.GRAY);
        button1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                String buttonString = ae.getActionCommand( );
                if(player1_isSelected && (p1Pokemon == 0) && !battle) { // Player 1's Turn ---------------------
                    if(buttonString.equals("Charizard")) {
                        // Creating a Pokemon from user choice
                        p1Pokemon = 1;
                        player1Pokemon = new Charizard( );
                        player1_isSelected = false;
                        player2_isSelected = true;
                        
                        // Prompting player 2
                        commentText.setText("Player 2, please select your Pokemon:");
                        textPanel.revalidate( );
                    } else {
                        System.out.println("Error: No 'player1Pokemon' is created and 'button1' != 'Charizard'");
                    }
                } else if (player1_isSelected && (p1Pokemon > 0) && !battle) {
                    // Move selection
                    if(buttonString.equals(player1Pokemon.getMove1())) {
                        p1SelectedMove = player1Pokemon.getMove1();
                        player1_isSelected = false;
                        player2_isSelected = true;
                        commentText.setText("Player 2, please select your move:");
                        textPanel.revalidate( );
                    }
                    
                    // Changes buttons to have move selection
                    button1.setText(player2Pokemon.getMove1());
                    button1.revalidate( );

                    button2.setText(player2Pokemon.getMove2());
                    button2.revalidate( );

                    button3.setText(player2Pokemon.getMove3());
                    button3.revalidate( );
                    
                    button4.setText(player2Pokemon.getMove4());
                    button4.revalidate( );
                    
                } else if(player2_isSelected && (p2Pokemon == 0) && !battle) { // Player 2's Turn ---------------------
                    if(buttonString.equals("Charizard")) {
                        // Creating a Pokemon from user choice
                        p2Pokemon = 1;
                        player2Pokemon = new Charizard( );
                        player1_isSelected = true;
                        player2_isSelected = false;
                        
                        // Prompting player 1
                        commentText.setText("Player 1, select your move:");
                        textPanel.revalidate( );
                        
                        // Creating adding buttons 4 & 5 to the panel
                        buttonPanel.add(button4);
                        button4.setText(player1Pokemon.getMove4());
                        button4.revalidate( );
                        buttonPanel.add(button5);
                        
                        // Changes buttons to have move selection
                        button1.setText(player1Pokemon.getMove1());
                        button1.revalidate( );
                        
                        button2.setText(player1Pokemon.getMove2());
                        button2.revalidate( );
                        
                        button3.setText(player1Pokemon.getMove3());
                        button3.revalidate( );
                        
                    } else {
                        System.out.println("Error: No 'player1Pokemon' is created and 'button1' != 'Charizard'");
                    }
                } else if (player2_isSelected && (p2Pokemon > 0) && !battle) {
                    // Move selection
                    if(buttonString.equals(player2Pokemon.getMove1())) {
                        p2SelectedMove = player2Pokemon.getMove1();
                    }
                    
                    // Prompting user to select the "Next" button
                    commentText.setText("Now select the 'Next' button to fight.");
                    textPanel.revalidate( );
                }
            }
        });
        buttonPanel.add(button1);
        
        // ------------------------------- BUTTON 2 -------------------------------
        button2 = new JButton("Blastoise");
        button2.setBackground(Color.GRAY);
        button2.addActionListener( new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                String buttonString = ae.getActionCommand( );
                if(player1_isSelected && (p1Pokemon == 0) && !battle) { // Player 1's Turn ---------------------
                    if(buttonString.equals("Blastoise")) {
                        // Creating a Pokemon from user choice
                        p1Pokemon = 2;
                        player1Pokemon = new Blastoise( );
                        player1_isSelected = false;
                        player2_isSelected = true;
                        
                        // Prompting player 2
                        commentText.setText("Player 2, please select your Pokemon:");
                        textPanel.revalidate( );
                    } else {
                        System.out.println("Error: No 'player1Pokemon' is created and 'button2' != 'Blastoise'");
                    }
                } else if (player1_isSelected && (p1Pokemon > 0) && !battle) {
                    // Move selection
                    if(buttonString.equals(player1Pokemon.getMove2())) {
                        p1SelectedMove = player1Pokemon.getMove2();
                        player1_isSelected = false;
                        player2_isSelected = true;
                        commentText.setText("Player 2, please select your move:");
                        textPanel.revalidate( );
                    }
                    
                    // Changes the buttons to have move selection
                    button1.setText(player2Pokemon.getMove1());
                    button1.revalidate( );
                    button2.setText(player2Pokemon.getMove2());
                    button2.revalidate( );
                    button3.setText(player2Pokemon.getMove3());
                    button3.revalidate( );
                    button4.setText(player2Pokemon.getMove4());
                    button4.revalidate( );
                } else if(player2_isSelected && (p2Pokemon == 0) && !battle) { // Player 2's Turn ---------------------
                    if(buttonString.equals("Blastoise")) {
                        // Creating a Pokemon from user choice
                        p2Pokemon = 2;
                        player2Pokemon = new Blastoise( );
                        player1_isSelected = true;
                        player2_isSelected = false;
                        
                        // Prompting player 1
                        commentText.setText("Player 1, select your move:");
                        textPanel.revalidate( );
                        
                        // Creating adding buttons 4 & 5 to the panel
                        buttonPanel.add(button4);
                        button4.setText(player1Pokemon.getMove4());
                        button4.revalidate( );
                        buttonPanel.add(button5);
                        
                        // Changes buttons to have move selection
                        button1.setText(player1Pokemon.getMove1());
                        button1.revalidate( );
                        
                        button2.setText(player1Pokemon.getMove2());
                        button2.revalidate( );
                        
                        button3.setText(player1Pokemon.getMove3());
                        button3.revalidate( );
                        
                    } else {
                        System.out.println("Error: No 'player1Pokemon' is created and 'button3' != 'Blastoise'");
                    }
                } else if (player2_isSelected && (p2Pokemon > 0) && !battle) {
                    // Move selection
                    if(buttonString.equals(player2Pokemon.getMove2())) {
                        p2SelectedMove = player2Pokemon.getMove2();
                    }
                    
                    // Prompting user to select the "Next" button
                    commentText.setText("Now select the 'Next' button to fight.");
                    textPanel.revalidate( );
                }
            }
        });
        buttonPanel.add(button2);
        
        // ------------------------------- BUTTON 3 -------------------------------
        button3 = new JButton("Venusaur");
        button3.setBackground(Color.GRAY);
        button3.addActionListener( new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                String buttonString = ae.getActionCommand( );
                if(player1_isSelected && (p1Pokemon == 0)) { // Player 1's Turn ---------------------
                    if(buttonString.equals("Venusaur")) {
                        // Creating a Pokemon from user choice
                        p1Pokemon = 3;
                        player1Pokemon = new Venusaur( );
                        player1_isSelected = false;
                        player2_isSelected = true;
                        
                        // Prompting player 2
                        commentText.setText("Player 2, please select your Pokemon:");
                        textPanel.revalidate( );
                    } else {
                        System.out.println("Error: No 'player1Pokemon' is created and 'button3' != 'Venusaur'");
                    }
                } else if (player1_isSelected && (p1Pokemon > 0) && !battle) {
                    // Move selection
                    if(buttonString.equals(player1Pokemon.getMove3())) {
                        p1SelectedMove = player1Pokemon.getMove3();
                        player1_isSelected = false;
                        player2_isSelected = true;
                        commentText.setText("Player 2, please select your move:");
                        textPanel.revalidate( );
                    }
                    
                    // Changes the buttons to have move selection
                    button1.setText(player2Pokemon.getMove1());
                    button1.revalidate( );

                    button2.setText(player2Pokemon.getMove2());
                    button2.revalidate( );

                    button3.setText(player2Pokemon.getMove3());
                    button3.revalidate( );

                    button4.setText(player2Pokemon.getMove4());
                    button4.revalidate( );
                } else if(player2_isSelected && (p2Pokemon == 0) && !battle) { // Player 2's Turn ---------------------
                    if(buttonString.equals("Venusaur")) {
                        // Creating a Pokemon from user choice
                        p2Pokemon = 3;
                        player2Pokemon = new Venusaur( );
                        player1_isSelected = true;
                        player2_isSelected = false;
                        
                        // Prompting player 1
                        commentText.setText("Player 1, select your move:");
                        textPanel.revalidate( );
                        
                        // Creating adding buttons 4 & 5 to the panel
                        buttonPanel.add(button4);
                        button4.setText(player1Pokemon.getMove4());
                        button4.revalidate( );
                        buttonPanel.add(button5);
                        
                        // Changes buttons to have move selection
                        button1.setText(player1Pokemon.getMove1());
                        button1.revalidate( );
                        
                        button2.setText(player1Pokemon.getMove2());
                        button2.revalidate( );
                        
                        button3.setText(player1Pokemon.getMove3());
                        button3.revalidate( );
                        
                    } else {
                        System.out.println("Error: No 'player1Pokemon' is created and 'button2' != 'Venusaur'");
                    }
                } else if (player2_isSelected && (p2Pokemon > 0) && !battle) {
                    // Move selection
                    if(buttonString.equals(player2Pokemon.getMove3())) {
                        p2SelectedMove = player2Pokemon.getMove3();
                    }
                    
                    // Prompting user to select the "Next" button
                    commentText.setText("Now select the 'Next' button to fight.");
                    textPanel.revalidate( );
                }
            }
        });
        buttonPanel.add(button3);
        
        // ------------------------------- BUTTON 4 -------------------------------
        button4 = new JButton("Default");
        button4.setBackground(Color.GRAY);
        button4.addActionListener( new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                String buttonString = ae.getActionCommand( );
                if (player1_isSelected && (p1Pokemon > 0) && !battle) {
                    // Move selection
                    if(buttonString.equals(player1Pokemon.getMove4())) {
                        p1SelectedMove = player1Pokemon.getMove4();
                        player1_isSelected = false;
                        player2_isSelected = true;
                        commentText.setText("Player 2, please select your move:");
                        textPanel.revalidate( );
                    }
                    
                    // Changes the buttons to have move selection
                    button1.setText(player2Pokemon.getMove1());
                    button1.revalidate( );

                    button2.setText(player2Pokemon.getMove2());
                    button2.revalidate( );

                    button3.setText(player2Pokemon.getMove3());
                    button3.revalidate( );

                    button4.setText(player2Pokemon.getMove4());
                    button4.revalidate( );
                } else if (player2_isSelected && (p2Pokemon > 0) && !battle) {
                    // Move selection
                    if(buttonString.equals(player2Pokemon.getMove4())) {
                        p2SelectedMove = player2Pokemon.getMove4();
                    }
                    
                    // Prompting user to select the "Next" button
                    commentText.setText("Now select the 'Next' button to fight.");
                    textPanel.revalidate( );
                }
            }
        });
        
        // ------------------------------- BUTTON 5 -------------------------------
        button5 = new JButton("Next");
        button5.setBackground(Color.GRAY);
        button5.addActionListener( new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                String buttonString = ae.getActionCommand( );
                if (player1_isSelected && (p1Pokemon > 0) && !battle) {
                    commentText.setText("Don't select the Next button just yet. Player 1, select your move.");
                    textPanel.revalidate( );
                } else if (player2_isSelected && (p2Pokemon > 0) && !battle) {
                    player1_isSelected = true;
                    player2_isSelected = false;
                    // ------------------------------------- BATTLE BEGINS! -------------------------------------
                        commentText.setText("<html>");
                        battle = true;
                        
                        // First the fastest Pokemon goes first
                        // Checks to see if the Pokemon can move based on status conditions.
                        // If the Pokemon can move, it chooses the move the player picked.
                        if (player1Pokemon.getSpd( ) >= player2Pokemon.getSpd( )) {
                            if (player1Pokemon.canMove(commentText)) {
                                if (player1Pokemon.getMove1() == p1SelectedMove) {
                                    player2Pokemon.damage(player1Pokemon.move1(player2Pokemon, 1, commentText), commentText);
                                } else if (player1Pokemon.getMove2() == p1SelectedMove) {
                                    player2Pokemon.damage(player1Pokemon.move2(player2Pokemon, 1, commentText), commentText);
                                } else if (player1Pokemon.getMove3() == p1SelectedMove) {
                                    player2Pokemon.damage(player1Pokemon.move3(player2Pokemon, 1, commentText), commentText);
                                } else if (player1Pokemon.getMove4() == p1SelectedMove) {
                                    player2Pokemon.damage(player1Pokemon.move4(player2Pokemon, 1, commentText), commentText);
                                }
                            }
                            // Checks to see if defending Pokemon fainted.
                            if (player2Pokemon.getCurrentHP( ) == 0) {
                                commentText.setText(commentText.getText() + "Player 2's Pokemon has fainted!<br>");
                                // Shows window that declares the window and prompts the user to close the program, or try again.
                            }
                        } else if (player2Pokemon.getSpd( ) > player1Pokemon.getSpd( )) {
                            if (player2Pokemon.canMove(commentText)) {
                                if (player2Pokemon.getMove1() == p2SelectedMove) {
                                    player1Pokemon.damage(player2Pokemon.move1(player1Pokemon, 1, commentText), commentText);
                                } else if (player2Pokemon.getMove2() == p2SelectedMove) {
                                    player1Pokemon.damage(player2Pokemon.move2(player1Pokemon, 1, commentText), commentText);
                                } else if (player2Pokemon.getMove3() == p2SelectedMove) {
                                    player1Pokemon.damage(player2Pokemon.move3(player1Pokemon, 1, commentText), commentText);
                                } else if (player2Pokemon.getMove4() == p2SelectedMove) {
                                    player1Pokemon.damage(player2Pokemon.move4(player1Pokemon, 1, commentText), commentText);
                                }
                            }
                            // Checks to see if defending Pokemon fainted.
                            if (player1Pokemon.getCurrentHP( ) == 0) {
                                commentText.setText(commentText.getText() + "Player 2's Pokemon has fainted!<br>");
                                // Shows window that declares the window and prompts the user to close the program, or try again.
                            }
                        }
                        
                        // Second the slowest Pokemon goes next
                        // Checks to see if the Pokemon can move based on status conditions.
                        // If the Pokemon can move, it chooses the move the player picked.
                        if (player1Pokemon.getSpd( ) < player2Pokemon.getSpd( )) {
                            if (player1Pokemon.canMove(commentText)) {
                                if (player1Pokemon.getMove1() == p1SelectedMove) {
                                    player2Pokemon.damage(player1Pokemon.move1(player2Pokemon, 1, commentText), commentText);
                                } else if (player1Pokemon.getMove2() == p1SelectedMove) {
                                    player2Pokemon.damage(player1Pokemon.move2(player2Pokemon, 1, commentText), commentText);
                                } else if (player1Pokemon.getMove3() == p1SelectedMove) {
                                    player2Pokemon.damage(player1Pokemon.move3(player2Pokemon, 1, commentText), commentText);
                                } else if (player1Pokemon.getMove4() == p1SelectedMove) {
                                    player2Pokemon.damage(player1Pokemon.move4(player2Pokemon, 1, commentText), commentText);
                                }
                            }
                            // Checks to see if defending Pokemon fainted.
                            if (player2Pokemon.getCurrentHP( ) == 0) {
                                commentText.setText(commentText.getText() + "Player 2's Pokemon has fainted!<br>");
                                // Shows window that declares the window and prompts the user to close the program, or try again.
                            }
                        } else if (player2Pokemon.getSpd( ) <= player1Pokemon.getSpd( )) {
                            if (player2Pokemon.canMove(commentText)) {
                                if (player2Pokemon.getMove1() == p2SelectedMove) {
                                    player1Pokemon.damage(player2Pokemon.move1(player1Pokemon, 1, commentText), commentText);
                                } else if (player2Pokemon.getMove2() == p2SelectedMove) {
                                    player1Pokemon.damage(player2Pokemon.move2(player1Pokemon, 1, commentText), commentText);
                                } else if (player2Pokemon.getMove3() == p2SelectedMove) {
                                    player1Pokemon.damage(player2Pokemon.move3(player1Pokemon, 1, commentText), commentText);
                                } else if (player2Pokemon.getMove4() == p2SelectedMove) {
                                    player1Pokemon.damage(player2Pokemon.move4(player1Pokemon, 1, commentText), commentText);
                                }
                            }
                            // Checks to see if defending Pokemon fainted.
                            if (player1Pokemon.getCurrentHP( ) == 0) {
                                commentText.setText(commentText.getText() + "Player 2's Pokemon has fainted!<br>");
                                // Shows window that declares the window and prompts the user to close the program, or try again.
                            }
                        }
                        
                        // Checks to see if the Pokemon take damage based on their status condition.
                        player1Pokemon.checkChipDMG(commentText);
                        player2Pokemon.checkChipDMG(commentText);
                        
                        // Posts the new text for the battle
                        commentText.setText(commentText.getText() + "Now, press 'Next' to continue.</html>");
                        textPanel.revalidate( );
                    
                    // ------------------------------------- BATTLE ENDS! -------------------------------------
                    p1SelectedMove = "";
                    p2SelectedMove = "";
                    
                    
                    /*commentText.setText("Player 1, select your move:");
                    textPanel.revalidate( );
                    textPanel.repaint( ); */
                } else if(battle) {
                    background.revalidate();
                    background.repaint();
                    commentText.setText("Player 1, select your move:");
                    textPanel.revalidate( );
                    
                    // Ensures the buttons and battle conditions are how they should be.
                    button1.setText(player1Pokemon.getMove1());
                    button1.revalidate( );

                    button2.setText(player1Pokemon.getMove2());
                    button2.revalidate( );

                    button3.setText(player1Pokemon.getMove3());
                    button3.revalidate( );

                    button4.setText(player1Pokemon.getMove4());
                    button4.revalidate( );
                    
                    player1_isSelected = true;
                    player2_isSelected = false;
                    
                    battle = false;
                }
            }
        });
        
        add(buttonPanel, BorderLayout.SOUTH);
        textPanel.add(commentText);
    }
    
    public static void main(String[] args) {
        FinalProject gui = new FinalProject( );
        gui.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}

class BackgroundPanel extends Panel
{
    // Image that stores the background
    Image img;
    public BackgroundPanel()
    {
        img = Toolkit.getDefaultToolkit().createImage("background.png");
    }
    
    @Override
    public void paint(Graphics g)
    {
        g.drawImage(img, 0, 0, null);
    }
}


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgfinal.project;

/**
 *
 * @author james
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Blastoise extends Pokemon{
    // Defines the names of the moves the Blastoise knows.
    private final String move1 = "Scald";
    private final String move2 = "Aura Sphere";
    private final String move3 = "Ice Beam";
    private final String move4 = "Dark Pulse";
    
    // Default constructor creates a basic Blastoise
    public Blastoise ( ) {
        super(299, 153, 237, 269, 246, 280);
        setType1("Water");
        setType2("None");
    }
    
    // Accessors only for the names of the moves. Defines abstract methods of parent class.
    @Override
    public String getMove1 ( ) {
        return move1;
    }
    
    @Override
    public String getMove2 ( ) {
        return move2;
    }
    
    @Override
    public String getMove3 ( ) {
        return move3;
    }
    
    @Override
    public String getMove4 ( ) {
        return move4;
    }
    
    // Move 1 simulates Scald and does damage calculations using enemy and weather. Has chance to burn enemy. Defines abstract method of parent class.
    @Override
    public int move1 (Pokemon enemy, double weather, JLabel aLabel) {
        double STAB = 1.5, crit, type, type1 = 1, type2 = 1;
        if (.0625 > Math.random( )) {
            crit = 2;
        } else {
            crit = 1;
        }
        double random = (Math.random( ) * (1 - 0.855)) + .855;
        
        if ("Fire".equals(enemy.getType1( )) || "Groud".equals(enemy.getType1( )) || "Rock".equals(enemy.getType1( ))) {
            type1 = 2;
        } else if ("Fire".equals(enemy.getType2( )) || "Groud".equals(enemy.getType2( )) || "Rock".equals(enemy.getType2( ))) {
            type2 = 2;
        }
        
        if ("Grass".equals(enemy.getType1( )) || "Water".equals(enemy.getType1( )) || "Dragon".equals(enemy.getType1( ))) {
            type1 = .5;
        } else if ("Grass".equals(enemy.getType2( )) || "Water".equals(enemy.getType2( )) || "Dragon".equals(enemy.getType2( ))) {
            type2 = .5;
        }
        
        type = type1 * type2;
        
        int damage = (int) Math.round((((((((((((2 * 100) / 5) + 2) * 80) * ((double) getSpAtk( ) / enemy.getSpDef( ))) / 50) + 2) * weather) * crit) * random) * STAB) * type);
        aLabel.setText(aLabel.getText() + "Blastoise used Scald!<br>");
        if (type == 0.0) {
            aLabel.setText(aLabel.getText() + "It was not effective!<br>");
        } else if(type < 1) {
            aLabel.setText(aLabel.getText() + "It wasn't very effective...<br>");
        } else if (type > 1) {
            aLabel.setText(aLabel.getText() + "It was super effective!<br>");
        }
        aLabel.setText(aLabel.getText() + "Blastoise dealt " + damage + " damage!<br>");
        if(0.3 > Math.random( )) {
            enemy.setStatus('B');
            enemy.refreshStats( );
            aLabel.setText(aLabel.getText() + "The opponent has been burned!<br>");
        }
        return damage;
    }
    
    // Move 2 simulates Aura Sphere and does damage calculations using enemy and weather. Defines abstract method of parent class.
    @Override
    public int move2 (Pokemon enemy, double weather, JLabel aLabel) {
        double STAB = 1, crit, type, type1 = 1, type2 = 1;
        if (.0625 > Math.random( )) {
            crit = 2;
        } else {
            crit = 1;
        }
        double random = (Math.random( ) * (1 - 0.855)) + .855;
        
        if ("Normal".equals(enemy.getType1( )) || "Ice".equals(enemy.getType1( )) || "Dark".equals(enemy.getType1( )) || "Rock".equals(enemy.getType1( )) || "Steel".equals(enemy.getType1( ))) {
            type1 = 2;
        } else if ("Normal".equals(enemy.getType2( )) || "Ice".equals(enemy.getType2( )) || "Dark".equals(enemy.getType2( )) || "Rock".equals(enemy.getType2( )) || "Steel".equals(enemy.getType2( ))) {
            type2 = 2;
        }
        
        if ("Poison".equals(enemy.getType1( )) || "Flying".equals(enemy.getType1( )) || "Psychic".equals(enemy.getType1( )) || "Bug".equals(enemy.getType1( )) || "Fairy".equals(enemy.getType1( ))) {
            type1 = .5;
        } else if ("Poison".equals(enemy.getType2( )) || "Flying".equals(enemy.getType2( )) || "Psychic".equals(enemy.getType2( )) || "Bug".equals(enemy.getType2( )) || "Fairy".equals(enemy.getType2( ))) {
            type2 = .5;
        }
        
        if ("Ghost".equals(enemy.getType1( ))) {
            type1 = 0;
        } else if ("Ghost".equals(enemy.getType2( ))) {
            type2 = 0;
        }
        
        type = type1 * type2;
        
        int damage = (int) Math.round((((((((((((2 * 100) / 5) + 2) * 80) * ((double) getSpAtk( ) / enemy.getSpDef( ))) / 50) + 2) * weather) * crit) * random) * STAB) * type);
        aLabel.setText(aLabel.getText() + "Blastoise used Aura Sphere!<br>");
        if (type == 0.0) {
            aLabel.setText(aLabel.getText() + "It was not effective!<br>");
        } else if(type < 1) {
            aLabel.setText(aLabel.getText() + "It wasn't very effective...<br>");
        } else if (type > 1) {
            aLabel.setText(aLabel.getText() + "It was super effective!<br>");
        }
        aLabel.setText(aLabel.getText() + "Blastoise dealt " + damage + " damage!<br>");
        return damage;
    }
    
    // Move 3 simulates Ice Beam and does damage calculations using enemy and weather. Has chance to freeze enemy. Defines abstract method of parent class.
    @Override
    public int move3 (Pokemon enemy, double weather, JLabel aLabel) {
        double STAB = 1, crit, type, type1 = 1, type2 = 1;
        if (.0625 > Math.random( )) {
            crit = 2;
        } else {
            crit = 1;
        }
        double random = (Math.random( ) * (1 - 0.855)) + .855;
        
        if ("Grass".equals(enemy.getType1( )) || "Ground".equals(enemy.getType1( )) || "Flying".equals(enemy.getType1( )) || "Dragon".equals(enemy.getType1( ))) {
            type1 = 2;
        } else if ("Grass".equals(enemy.getType2( )) || "Ground".equals(enemy.getType2( )) || "Flying".equals(enemy.getType2( )) || "Dragon".equals(enemy.getType2( ))) {
            type2 = 2;
        }
        
        if ("Fire".equals(enemy.getType1( )) || "Water".equals(enemy.getType1( )) || "Ice".equals(enemy.getType1( )) || "Steel".equals(enemy.getType1( ))) {
            type1 = .5;
        } else if ("Fire".equals(enemy.getType2( )) || "Water".equals(enemy.getType2( )) || "Ice".equals(enemy.getType2( )) || "Steel".equals(enemy.getType2( ))) {
            type2 = .5;
        }
        
        type = type1 * type2;
        
        int damage = (int) Math.round((((((((((((2 * 100) / 5) + 2) * 90) * ((double) getSpAtk( ) / enemy.getSpDef( ))) / 50) + 2) * weather) * crit) * random) * STAB) * type);
        aLabel.setText(aLabel.getText() + "Blastoise used Ice Beam!<br>");
        if (type == 0.0) {
            aLabel.setText(aLabel.getText() + "It was not effective!<br>");
        } else if(type < 1) {
            aLabel.setText(aLabel.getText() + "It wasn't very effective...<br>");
        } else if (type > 1) {
            aLabel.setText(aLabel.getText() + "It was super effective!<br>");
        }
        aLabel.setText(aLabel.getText() + "Blastoise dealt " + damage + " damage!<br>");
        if(0.1 > Math.random( )) {
            enemy.setStatus('F');
            enemy.refreshStats( );
            aLabel.setText(aLabel.getText() + "The opponent has been frozen!<br>");
        }
        return damage;
    }
    
    // Move 4 simulates Dark Pulse and does damage calculations using enemy and weather. Has chance to make enemy flinch. Defines abstract method of parent class.
    @Override
    public int move4 (Pokemon enemy, double weather, JLabel aLabel) {
        double STAB = 1, crit, type, type1 = 1, type2 = 1;
        if (.0625 > Math.random( )) {
            crit = 2;
        } else {
            crit = 1;
        }
        double random = (Math.random( ) * (1 - 0.855)) + .855;
        
        if ("Psychic".equals(enemy.getType1( )) || "Rock".equals(enemy.getType1( ))) {
            type1 = 2;
        } else if ("Psychic".equals(enemy.getType2( )) || "Rock".equals(enemy.getType2( ))) {
            type2 = 2;
        }
        
        if ("Poison".equals(enemy.getType1( )) || "Dark".equals(enemy.getType1( )) || "Fairy".equals(enemy.getType1( ))) {
            type1 = .5;
        } else if ("Poison".equals(enemy.getType2( )) || "Dark".equals(enemy.getType2( )) || "Fairy".equals(enemy.getType2( ))) {
            type2 = .5;
        }
        
        type = type1 * type2;
        
        int damage = (int) Math.round((((((((((((2 * 100) / 5) + 2) * 80) * ((double) getSpAtk( ) / enemy.getSpDef( ))) / 50) + 2) * weather) * crit) * random) * STAB) * type);
        aLabel.setText(aLabel.getText() + "Blastoise used Dark Pulse!<br>");
        if (type == 0.0) {
            aLabel.setText(aLabel.getText() + "It was not effective!<br>");
        } else if(type < 1) {
            aLabel.setText(aLabel.getText() + "It wasn't very effective...<br>");
        } else if (type > 1) {
            aLabel.setText(aLabel.getText() + "It was super effective!<br>");
        }
        aLabel.setText(aLabel.getText() + "Blastoise dealt " + damage + " damage!<br>");
        if(0.2 > Math.random( )) {
            enemy.setStatus('L');
            enemy.refreshStats( );
        }
        return damage;
    }
}
